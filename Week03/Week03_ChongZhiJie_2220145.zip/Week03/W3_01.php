<?php
echo "Hello World";
?>

<?php
echo "<h2 style='color:green'>Hello World!</h2>";
?>

<?php
echo "<h1 style='color:black'>Produce HTML Page By using php Code</h1>";
?>

<?php
echo "This is the example of using the php code to do a normal html page";
echo "<br>";
?>

<?php
echo "How is your felling when using PHP code to produce the html code ?";
echo "<br>";
?>

<?php
echo "<img src='img_girl.jpg'>";
?>