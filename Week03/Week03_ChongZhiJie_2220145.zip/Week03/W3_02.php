<?php
$age=5;//value in age =5
echo $age,"<BR>\n";
$age=8;//value 5 now replace with value 8
echo $age,"<BR>\n";
?>

<?php
echo '"This","string","was","made","with multiple parameters."';
?>